var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/notifications/route.js")
R.c("server/chunks/[root-of-the-server]__74779451._.js")
R.c("server/chunks/[root-of-the-server]__63d2c3f8._.js")
R.c("server/chunks/[root-of-the-server]__621d43d4._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_notifications_route_actions_b9bcec48.js")
R.m(43424)
module.exports=R.m(43424).exports
