var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/users/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__bdd690fc._.js")
R.c("server/chunks/2f573_bcryptjs_index_6869504d.js")
R.c("server/chunks/[root-of-the-server]__63d2c3f8._.js")
R.c("server/chunks/[root-of-the-server]__621d43d4._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_users_[id]_route_actions_b7a31f56.js")
R.m(82554)
module.exports=R.m(82554).exports
