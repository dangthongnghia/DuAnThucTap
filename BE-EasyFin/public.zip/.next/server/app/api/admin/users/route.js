var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/users/route.js")
R.c("server/chunks/[root-of-the-server]__c6b9c7be._.js")
R.c("server/chunks/2f573_bcryptjs_index_6869504d.js")
R.c("server/chunks/[root-of-the-server]__63d2c3f8._.js")
R.c("server/chunks/[root-of-the-server]__621d43d4._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_users_route_actions_595e9dd9.js")
R.m(39683)
module.exports=R.m(39683).exports
