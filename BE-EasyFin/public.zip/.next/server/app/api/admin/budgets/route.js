var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/budgets/route.js")
R.c("server/chunks/[root-of-the-server]__0794403f._.js")
R.c("server/chunks/[root-of-the-server]__63d2c3f8._.js")
R.c("server/chunks/[root-of-the-server]__621d43d4._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_budgets_route_actions_982e43a0.js")
R.m(40722)
module.exports=R.m(40722).exports
