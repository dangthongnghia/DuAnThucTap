var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/stats/route.js")
R.c("server/chunks/[root-of-the-server]__c8017151._.js")
R.c("server/chunks/[root-of-the-server]__63d2c3f8._.js")
R.c("server/chunks/[root-of-the-server]__621d43d4._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_stats_route_actions_05832952.js")
R.m(22332)
module.exports=R.m(22332).exports
