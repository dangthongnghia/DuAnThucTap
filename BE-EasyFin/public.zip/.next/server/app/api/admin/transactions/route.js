var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/transactions/route.js")
R.c("server/chunks/[root-of-the-server]__d3aeb526._.js")
R.c("server/chunks/[root-of-the-server]__63d2c3f8._.js")
R.c("server/chunks/[root-of-the-server]__621d43d4._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_transactions_route_actions_cc25e25e.js")
R.m(48607)
module.exports=R.m(48607).exports
