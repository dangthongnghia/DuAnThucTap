var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/accounts/route.js")
R.c("server/chunks/[root-of-the-server]__4cf1c6b1._.js")
R.c("server/chunks/[root-of-the-server]__63d2c3f8._.js")
R.c("server/chunks/[root-of-the-server]__621d43d4._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_accounts_route_actions_18d80dd3.js")
R.m(81251)
module.exports=R.m(81251).exports
