var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/categories/route.js")
R.c("server/chunks/[root-of-the-server]__9bb3b28f._.js")
R.c("server/chunks/[root-of-the-server]__63d2c3f8._.js")
R.c("server/chunks/[root-of-the-server]__621d43d4._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_categories_route_actions_c6642720.js")
R.m(33682)
module.exports=R.m(33682).exports
