var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/register/route.js")
R.c("server/chunks/[root-of-the-server]__03dab0ee._.js")
R.c("server/chunks/[root-of-the-server]__63d2c3f8._.js")
R.c("server/chunks/2f573_bcryptjs_index_6869504d.js")
R.c("server/chunks/_next-internal_server_app_api_auth_register_route_actions_3564e727.js")
R.m(158)
module.exports=R.m(158).exports
