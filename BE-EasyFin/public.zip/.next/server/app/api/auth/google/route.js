var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/google/route.js")
R.c("server/chunks/[root-of-the-server]__51a764a0._.js")
R.c("server/chunks/[root-of-the-server]__63d2c3f8._.js")
R.c("server/chunks/[root-of-the-server]__621d43d4._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_google_route_actions_5a4bf5a2.js")
R.m(34266)
module.exports=R.m(34266).exports
