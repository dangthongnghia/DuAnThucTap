var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/accounts/summary/route.js")
R.c("server/chunks/[root-of-the-server]__81df217b._.js")
R.c("server/chunks/[root-of-the-server]__63d2c3f8._.js")
R.c("server/chunks/[root-of-the-server]__621d43d4._.js")
R.c("server/chunks/_next-internal_server_app_api_accounts_summary_route_actions_fb521bbb.js")
R.m(45619)
module.exports=R.m(45619).exports
