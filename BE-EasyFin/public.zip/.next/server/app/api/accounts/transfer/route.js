var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/accounts/transfer/route.js")
R.c("server/chunks/[root-of-the-server]__807bcb7d._.js")
R.c("server/chunks/[root-of-the-server]__63d2c3f8._.js")
R.c("server/chunks/[root-of-the-server]__621d43d4._.js")
R.c("server/chunks/_next-internal_server_app_api_accounts_transfer_route_actions_562c4c69.js")
R.m(12900)
module.exports=R.m(12900).exports
