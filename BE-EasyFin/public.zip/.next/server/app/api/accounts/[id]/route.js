var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/accounts/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__154c89ce._.js")
R.c("server/chunks/[root-of-the-server]__63d2c3f8._.js")
R.c("server/chunks/[root-of-the-server]__621d43d4._.js")
R.c("server/chunks/_next-internal_server_app_api_accounts_[id]_route_actions_0fe03500.js")
R.m(32080)
module.exports=R.m(32080).exports
