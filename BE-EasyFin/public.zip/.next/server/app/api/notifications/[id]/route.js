var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/notifications/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__537688d2._.js")
R.c("server/chunks/[root-of-the-server]__63d2c3f8._.js")
R.c("server/chunks/[root-of-the-server]__621d43d4._.js")
R.c("server/chunks/_next-internal_server_app_api_notifications_[id]_route_actions_233733f6.js")
R.m(57897)
module.exports=R.m(57897).exports
