var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/notifications/route.js")
R.c("server/chunks/[root-of-the-server]__58b2ed93._.js")
R.c("server/chunks/[root-of-the-server]__63d2c3f8._.js")
R.c("server/chunks/[root-of-the-server]__621d43d4._.js")
R.c("server/chunks/_next-internal_server_app_api_notifications_route_actions_850cb780.js")
R.m(45944)
module.exports=R.m(45944).exports
