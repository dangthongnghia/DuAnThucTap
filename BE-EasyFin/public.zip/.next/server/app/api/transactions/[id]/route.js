var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/transactions/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__df77bd07._.js")
R.c("server/chunks/[root-of-the-server]__63d2c3f8._.js")
R.c("server/chunks/[root-of-the-server]__621d43d4._.js")
R.c("server/chunks/_next-internal_server_app_api_transactions_[id]_route_actions_3996942e.js")
R.m(87703)
module.exports=R.m(87703).exports
