var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/transactions/route.js")
R.c("server/chunks/[root-of-the-server]__9f81827a._.js")
R.c("server/chunks/[root-of-the-server]__63d2c3f8._.js")
R.c("server/chunks/[root-of-the-server]__621d43d4._.js")
R.c("server/chunks/_next-internal_server_app_api_transactions_route_actions_73a9eae1.js")
R.m(36504)
module.exports=R.m(36504).exports
