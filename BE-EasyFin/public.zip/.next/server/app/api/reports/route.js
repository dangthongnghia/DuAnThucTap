var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/reports/route.js")
R.c("server/chunks/[root-of-the-server]__ebb53970._.js")
R.c("server/chunks/ef544_next_dist_esm_build_templates_app-route_13e43f51.js")
R.c("server/chunks/[root-of-the-server]__63d2c3f8._.js")
R.c("server/chunks/[root-of-the-server]__621d43d4._.js")
R.c("server/chunks/_next-internal_server_app_api_reports_route_actions_decaabe5.js")
R.m(41546)
module.exports=R.m(41546).exports
