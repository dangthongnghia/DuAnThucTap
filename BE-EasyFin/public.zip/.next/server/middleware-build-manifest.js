globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/b0f1b765e713355d.js",
    "static/chunks/216e9fdc11ba725d.js",
    "static/chunks/b90291378dae0300.js",
    "static/chunks/005d262c3b6b5af4.js",
    "static/chunks/ae620bfccf9bdaef.js",
    "static/chunks/turbopack-fd2aecdcd5d23a8f.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];