module.exports=[48882,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_accounts_page_actions_70db30ad.js.map