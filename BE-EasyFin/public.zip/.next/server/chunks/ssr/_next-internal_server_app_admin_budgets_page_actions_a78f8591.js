module.exports=[22491,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_budgets_page_actions_a78f8591.js.map