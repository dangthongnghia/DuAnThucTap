module.exports=[87148,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_reports_page_actions_a8d1615f.js.map