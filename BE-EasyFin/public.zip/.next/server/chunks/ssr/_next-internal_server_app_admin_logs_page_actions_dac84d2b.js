module.exports=[52224,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_logs_page_actions_dac84d2b.js.map