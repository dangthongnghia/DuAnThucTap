module.exports=[94963,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_transactions_page_actions_64abf313.js.map