module.exports=[37912,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_accounts_transfer_route_actions_562c4c69.js.map