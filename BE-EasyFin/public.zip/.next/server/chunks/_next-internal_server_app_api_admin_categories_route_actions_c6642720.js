module.exports=[77442,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_categories_route_actions_c6642720.js.map