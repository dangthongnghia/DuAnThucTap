module.exports=[6249,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_reports_route_actions_decaabe5.js.map