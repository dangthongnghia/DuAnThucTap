module.exports=[46817,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_notifications_route_actions_b9bcec48.js.map