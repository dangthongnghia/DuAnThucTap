module.exports=[16635,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_budgets_route_actions_982e43a0.js.map