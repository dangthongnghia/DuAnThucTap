module.exports=[28969,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_accounts_%5Bid%5D_route_actions_0fe03500.js.map