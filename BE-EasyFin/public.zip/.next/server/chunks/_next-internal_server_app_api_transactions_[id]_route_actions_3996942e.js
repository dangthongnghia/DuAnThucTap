module.exports=[28329,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_transactions_%5Bid%5D_route_actions_3996942e.js.map