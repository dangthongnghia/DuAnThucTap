module.exports=[85864,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_users_%5Bid%5D_route_actions_b7a31f56.js.map