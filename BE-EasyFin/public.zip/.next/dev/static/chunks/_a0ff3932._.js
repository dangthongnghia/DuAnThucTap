(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_b5e3b497._.js",
  "static/chunks/ef544_next_dist_compiled_react-dom_38c88cf4._.js",
  "static/chunks/ef544_next_dist_compiled_react-server-dom-turbopack_68a1a768._.js",
  "static/chunks/ef544_next_dist_compiled_next-devtools_index_b3341105.js",
  "static/chunks/ef544_next_dist_compiled_20ab489d._.js",
  "static/chunks/ef544_next_dist_client_3c7ce123._.js",
  "static/chunks/ef544_next_dist_7a48e014._.js",
  "static/chunks/69652_@swc_helpers_cjs_679851cc._.js"
],
    source: "entry"
});
